@echo off
start "" "%~dp0Stillwater-The-Last-Tide.exe"
